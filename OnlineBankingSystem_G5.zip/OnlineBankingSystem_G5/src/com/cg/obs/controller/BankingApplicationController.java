package com.cg.obs.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;

@WebServlet(urlPatterns = { "/BankingApplicationController", "/Login",
		"/GetMiniTransactions", "/GetDetailedTransactions", "/UpdateProfile",
		"/UpdateProfileSuccess", "/FundTransferPayment", "/FundTransfer",
		"/AddPayee", "/ValidateURN", "/ProcessTransaction","/ChqBookRqstSuccess", "/Adminlogin",
		"/AdminPage", "/CreateAcc", "/InsertAccount", "/Daily", "/Monthly",
		"/Yearly", "/ChangePassword", "/track" })
public class BankingApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;

	public BankingApplicationController() {

		userService = new UserServiceImpl();
	}

	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		System.out.println("path:" + path);
		String url = "";
		List<Transactions> tList = null;

		switch (path) {
		
		case "/Login": {
			String id = request.getParameter("username");
			String password = request.getParameter("password");

			int hitCounter = 0;
			Users user = userService.getUser(Integer.parseInt(id));
			System.out.println(user);
			if (user != null) {
				if (user.getLockStatus() != "L")

				{

					if (password.equalsIgnoreCase(user.getLoginPassword())) {
						System.out.println(user.getLoginPassword());
						url = "Projects/index.jsp";

						/*
						 * request.setAttribute("userid", user.getUserId());
						 * request.setAttribute("accountno",
						 * user.getAccountId());
						 */
						HttpSession session = request.getSession();
						session.setAttribute("accountno", user.getAccountId());

						session.setAttribute("userid", id);
					} else {
						hitCounter++;
						System.out.println(hitCounter);
						if (hitCounter == 3) {
							userService.updateLockStatus(user.getUserId());
							System.out.println("Your Account Locked");

							throw new UserException("Your Account is locked");
						}
						url = "#";
					}
				} else {
					System.out.println("Wrong Password" + hitCounter);
				}
			} else {
				throw new UserException("No User Exists.....");
			}

			break;
		}
		case "/GetMiniTransactions": {
			HttpSession session = request.getSession(false);
			Long accountno = (Long) session.getAttribute("accountno");
			System.out.println("In getminitrans accountno:" + accountno);
			// Long accountno=Long.parseLong(accountid);
			List<Transactions> miniTransList = userService
					.getMiniTransactions(accountno);
			System.out.println("miniTransList:" + miniTransList);
			request.setAttribute("miniTransactionList", miniTransList);
			url = "Projects/pages/MiniTransactions.jsp";
			break;
		}
		case "/GetDetailedTransactions": {
			HttpSession session = request.getSession(false);
			Long accountno = (Long) session.getAttribute("accountno");
			System.out.println("In getdetailedtrans accountno:" + accountno);
			Date fromDate = Date.valueOf(request.getParameter("fromDate"));
			Date toDate = Date.valueOf(request.getParameter("toDate"));

			List<Transactions> detailedTransList = userService
					.getDetailedTransactions(accountno, fromDate, toDate);
			System.out.println("detailedTransList:" + detailedTransList);
			request.setAttribute("detailedTransactionList", detailedTransList);
			url = "Projects/pages/DetailedTransactions.jsp";
			break;
		}

		case "/UpdateProfile": {
			Customer customer = null;

			HttpSession session = request.getSession(false);
			Long accountno = (Long) session.getAttribute("accountno");
			int customerid = (Integer) userService.getCustomerId(accountno);
			customer = userService.getCustomer(customerid);
			request.setAttribute("customer_ID", customer.getCustomer_ID());
			request.setAttribute("customer_Name", customer.getCustomer_Name());
			request.setAttribute("email", customer.getEmail());
			request.setAttribute("mobileNo", customer.getMobileNo());
			request.setAttribute("address", customer.getAddress());
			request.setAttribute("pancard", customer.getPancard());
			url = "Projects/pages/UpdateProfile.jsp";
			break;
		}

		case "/UpdateProfileSuccess": {
			System.out.println("in update sucess");
			int customerId = Integer.parseInt(request
					.getParameter("customerid"));
			String cname = request.getParameter("customerName");
			String email = request.getParameter("email");
			Long mobileno = Long.parseLong(request.getParameter("mobileNo"));
			String address = request.getParameter("address");
			String pancard = request.getParameter("pancard");

			Customer customer = new Customer();
			customer.setCustomer_ID(customerId);
			customer.setCustomer_Name(cname);
			customer.setEmail(email);
			customer.setMobileNo(mobileno);
			customer.setAddress(address);
			customer.setPancard(pancard);

			System.out.println("in update sucess" + customer);
			userService.updateCustomerDetails(customer);
			System.out.println("update sucess");
			url = "Projects/pages/UpdateProfileSuccess.jsp";
			break;

		}

		case "/FundTransfer": {
			HttpSession session = request.getSession(false);
			Long accountno = (Long) session.getAttribute("accountno");
			List<Payee> payeeList = userService.getPayee(accountno);
			request.setAttribute("payeeList", payeeList);
			url = "Projects/pages/FundTransfer.jsp";
			break;
		}
		case "/AddPayee": {
			HttpSession session = request.getSession(false);
			Long accountno = (Long) session.getAttribute("accountno");

			Long payeeAccountNo = Long.parseLong(request
					.getParameter("txtAccountNo"));
			String payeeNickname = request.getParameter("txtNickName");
			System.out.println("in add payee");
			if (userService.isPayeeAccountExists(payeeAccountNo)) {

				int randomInt = (int) (10.0 * Math.random());

				// request.setAttribute("urncode",randomInt);
				HttpSession urncodesession = request.getSession();
				urncodesession.setAttribute("urncode", randomInt);
				request.setAttribute("urncode", randomInt);
				System.out.println("urncode" + randomInt);
				urncodesession.setAttribute("payeeAccountNo", payeeAccountNo);
				urncodesession.setAttribute("payeeNickName", payeeNickname);

				url = "Projects/pages/PayeeSuccess.jsp";
				/*
				 * Payee payee=new Payee(); payee.setAccountno(accountno);
				 * payee.setPayeeAccountNo(payeeAccountNo);
				 * payee.setNickName(payeeNickname);
				 * 
				 * userService.insertPayee(payee);
				 */
			}
			// url="Projects/pages/PayeeSuccess.jsp";
			break;
		}

		case "/ValidateURN": {
			int urnEntered = Integer.valueOf(request.getParameter("txtURN"));
			HttpSession session = request.getSession(false);
			int generatedUrnCode = (int) session.getAttribute("urncode");
			HttpSession validatesession = request.getSession(false);
			Long accountno = (Long) validatesession.getAttribute("accountno");
			Long payeeAccountNo = (Long) validatesession
					.getAttribute("payeeAccountNo");
			String payeeNickname = (String) validatesession
					.getAttribute("payeeNickName");

			if (urnEntered == generatedUrnCode) {
				Payee payee = new Payee();
				payee.setAccountno(accountno);
				payee.setPayeeAccountNo(payeeAccountNo);
				payee.setNickName(payeeNickname);

				userService.insertPayee(payee);
				url = "Projects/pages/URNSuccess.jsp";
				break;
			} else {
				url = "#";
				break;
			}
		}

		case "/FundTransferPayment": {
			System.out.println("in fundtransferpayment ctrl");
			String payeeAccountno = request.getParameter("selectpayee");
			HttpSession session = request.getSession();
			session.setAttribute("payeeaccountno", payeeAccountno);
			System.out.println("Going to pay:" + payeeAccountno);
			url = "Projects/pages/FTPay.jsp";

			break;
		}

		case "/ProcessTransaction": {
			Users user = null;
			Transactions transaction = null;
			FundTransfer transferInfo = null;
			double transactionAmount = Double.parseDouble(request
					.getParameter("txtAmount"));
			String password = request.getParameter("txtPwd");

			HttpSession session = request.getSession(false);
			Long accountno = (Long) session.getAttribute("accountno");
			int customerid = (Integer) userService.getCustomerId(accountno);

			int userid = (int) session.getAttribute("userid");

			user = userService.getUser(customerid);
			AccountMaster account = userService.getAccount(accountno);

			if (user.getTransPassword() == password) {
				if (account.getAccountBalance() > transactionAmount) {
					Double balance = account.getAccountBalance();
					Double updatedBalance = balance - transactionAmount;

					long millis = System.currentTimeMillis();
					java.sql.Date date = new java.sql.Date(millis);

					userService.fundTransfer(transferInfo);
					userService.insertTransaction(transaction);
					userService.updateBalance(updatedBalance, accountno);

					url = "Projects/pages/FTSuccess.jsp";
				} else {
					url = "Projects/pages/ErrorPage.jsp";
				}
			} else {
				url = "Projects/pages/ErrorPage.jsp";
			}
			break;

		}

		case "/ChqBookRqstSuccess":

			ServiceTracker tracker = null;

			System.out.println("start");
			HttpSession session = request.getSession(false);
			//String accno=(String)session.getAttribute("accountno");
			//Long accountno=Long.parseLong(accno);
			Long accountno=(Long)session.getAttribute("accountno");
			System.out.println(accountno);
			int serviceid=userService.isCheckBookRequestExist(accountno);
			if(serviceid==0)
			{
				
				HttpSession serviceIdsession = request.getSession();
				serviceIdsession.setAttribute("serviceId", serviceid);

				
			// String desc=(String)session.getAttribute("Send request");
			String desc = "Cheque Book request";
			System.out.println(desc);
			// long accId=(long)session.getAttribute("123");
						// Date risedDate=(Date)session.getAttribute("2017-09-09");

			// String myDate="09/09/2017";
		
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);

			System.out.println(date);
			// String status=(String)session.getAttribute("Processing");
			String status = "proccessing";

			tracker = new ServiceTracker();

			tracker.setService_Description(desc);
			tracker.setAccount_ID(accountno);
			tracker.setService_Raised_Date(date);
			tracker.setService_Status(status);

			System.out.println(tracker);

			int id = userService.requestService(tracker);

			System.out.println("in ctrl id:" + id);

			request.setAttribute("tracker", id);
			System.out.println(tracker);

			url = "Projects/pages/ChqBookRqstSuccess.jsp";
			break;
			}
			else
			{
				url="Projects/pages/ChqBookRqstExist.jsp";
				break;
			}
			
			
		// Admin methods.
		case "/Adminlogin":
			String adUser = request.getParameter("username");
			String pass = request.getParameter("password");
			if (adUser.equalsIgnoreCase("admin")
					&& pass.equalsIgnoreCase("admin")) {
				url = "Projects/adminIndex.jsp";
			}

			break;
		case "/AdminPage":
			List<RequestTable> req_List = userService.getAllRequest();
			request.setAttribute("List", req_List);
			System.out.println(req_List);

			url = "./Projects/pages/ViewRequestPage.jsp";

			break;
		case "/CreateAcc":

			String cust_ID = request.getParameter("custId");
			int cust = Integer.parseInt(cust_ID);

			RequestTable req = new RequestTable();
			Customer customer = new Customer();

			customer = userService.getCustomerbyId(cust);
			req = userService.getAccountId(cust);

			request.setAttribute("customer", customer);
			request.setAttribute("Request", req);

			url = "Projects/pages/CreateAccount.jsp";

			break;
			
		case "/InsertAccount":

			int accountID = Integer.parseInt(request.getParameter("accountId"));
			String a_type = request.getParameter("txtacctype");
			float balance = Float
					.parseFloat(request.getParameter("txtbalance"));
			String open_date = request.getParameter("txtdate");
			int cus_ID = Integer.parseInt(request.getParameter("txtcustid"));
			try {
				DateTimeFormatter format = DateTimeFormatter
						.ofPattern("yyyy-MM-dd");
				LocalDate localDate1 = LocalDate.parse(open_date, format);
				java.sql.Date openSqlDate = java.sql.Date.valueOf(localDate1);

				if (userService.isCustomerExist(cus_ID)) {

					AccountMaster account = new AccountMaster();
					account.setAccountId(accountID);
					account.setAccountType(a_type);
					account.setCustomerId(cus_ID);
					account.setAccountBalance(balance);
					account.setOpenDate(openSqlDate);

					int account_id = userService.addUsers(account);
					request.setAttribute("Account_ID", account_id);

					url = "Projects/pages/SuccessReg.jsp";
				} else {
					String err = "Customer Doesnt exist \n Unable to add account";
					request.setAttribute("error", err);
					url = "Projects/pages/CreateAccount.jsp";

				}

			}

			catch (Exception e) {
				throw new UserException("Unable to add Account"
						+ e.getMessage());
			}
			break;
		case "/Daily":

			String startDate = request.getParameter("date");
			java.sql.Date sqlStartDate;
			try {
				/*SimpleDateFormat sdf1 = new SimpleDateFormat("MM-dd-yyyy");
				java.util.Date date = sdf1.parse(startDate);
				sqlStartDate = new java.sql.Date(date.getTime());*/
				
				DateTimeFormatter format = DateTimeFormatter
						.ofPattern("yyyy-MM-dd");
				LocalDate localDate1 = LocalDate.parse(startDate, format);
				java.sql.Date sqlStartDate1 = java.sql.Date.valueOf(localDate1);

				
				System.out.println(sqlStartDate1);
				tList = userService.viewDailyReport(sqlStartDate1);
				request.setAttribute("tList", tList);

				url = "Projects/pages/DailyTransactions.jsp";

			}

			catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		case "/Monthly":
			String strtDate = request.getParameter("sdate");
			java.sql.Date sqlStrtDate;
			String endDate = request.getParameter("edate");
			java.sql.Date sqlEndDate;
			try {
				/*SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date sdate = sdf1.parse(strtDate);
				sqlStrtDate = new java.sql.Date(sdate.getTime());*/
				
				DateTimeFormatter format = DateTimeFormatter
						.ofPattern("yyyy-MM-dd");
				LocalDate localDate1 = LocalDate.parse(strtDate, format);
				java.sql.Date sqStartDate1 = java.sql.Date.valueOf(localDate1);

				

				/*SimpleDateFormat edf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date edate = edf1.parse(endDate);
				sqlEndDate = new java.sql.Date(edate.getTime());*/
				
				  DateTimeFormatter forma = DateTimeFormatter
						.ofPattern("yyyy-MM-dd");
				LocalDate localDate2 = LocalDate.parse(endDate, forma);
				java.sql.Date sqlEndDate1 = java.sql.Date.valueOf(localDate2);

				 

				tList = userService.viewMonthlyReport(sqStartDate1, sqlEndDate1);
				request.setAttribute("tList", tList);
				url = "Projects/pages/MonthlyTransactions.jsp";

			}

			catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		case "/Yearly":

			String sDate = request.getParameter("sdate");
			java.sql.Date sqlSDate;
			String eDate = request.getParameter("edate");
			java.sql.Date sqlEDate;
			try {
/*				SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date sdate = sdf2.parse(sDate);
				sqlSDate = new java.sql.Date(sdate.getTime());

				SimpleDateFormat edf2 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date edate = edf2.parse(eDate);
				sqlEDate = new java.sql.Date(edate.getTime());*/
				
				
				
				DateTimeFormatter format = DateTimeFormatter
						.ofPattern("yyyy-MM-dd");
				LocalDate localDate1 = LocalDate.parse(sDate, format);
				java.sql.Date StartDate1 = java.sql.Date.valueOf(localDate1);

				

				
				
				  DateTimeFormatter forma = DateTimeFormatter
						.ofPattern("yyyy-MM-dd");
				LocalDate localDate2 = LocalDate.parse(eDate, forma);
				java.sql.Date EndDate1 = java.sql.Date.valueOf(localDate2);


				 

				tList = userService.viewYearlyReport(StartDate1, EndDate1);
				request.setAttribute("tList", tList);
				url = "Projects/pages/YearlyTransactions.jsp";

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			break;


		case "/ChangePassword":

			String old = request.getParameter("oldPass");

			String newPass = request.getParameter("newPass");
			String CPass = request.getParameter("confirmPass");

			Users users = new Users();
			HttpSession usersession = request.getSession(false);
			String id = (String) usersession.getAttribute("userid");
			int userid=Integer.parseInt(id);
			users=userService.getUser(userid);
	
			if(old.equalsIgnoreCase(users.getLoginPassword()))
			{
				System.out.println("valid password");
			if (newPass.equals(CPass)) {
				System.out.println("equals password");
				users.setLoginPassword(CPass);
				userService.changePassword(users);

				url = "Projects/pages/ChangePasswordSuccess.jsp";

			} else {
				url = "Projects/pages/ErrorPage.jsp";
			}
			
			break;
			}
			else
			{
				url="Projects/pages/ErrorPage.jsp";
			}
			
			
		case "/track":
		{
			String request_id=request.getParameter("requestId");
			int requestid=Integer.parseInt(request_id);
			System.out.println(request_id);
			try {
				ServiceTracker tracker1 = new ServiceTracker();
				tracker1=userService.getRequestedServiceList(requestid);
				request.setAttribute("trackservice",tracker1);
				url="Projects/pages/ShowServiceTrack.jsp";
				break;
					
				} catch (UserException e) {
					e.printStackTrace();
				}

			} 
		break;
	}
		
		
		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);

	}

}
